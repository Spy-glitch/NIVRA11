# 📱 NIVRA - Mobile Deployment Guide (iPhone/Android)

## 🚀 Easiest Method: Netlify Drop

### Step 1: Prepare Files
1. Download `nivra-static.zip`
2. Open **Files app** on your phone
3. Tap the ZIP to extract it
4. You should see a folder called `nivra-static`

### Step 2: Upload to Netlify
1. Open Safari/Chrome → Go to [netlify.com](https://netlify.com)
2. Sign up (free) with email or GitHub
3. Once logged in, look for **"Deploy manually"** or **"Netlify Drop"**
4. **IMPORTANT**: On mobile, you need to use the **"Deploy manually"** button
5. Tap **"Choose Folder"** or **"Upload"** button
6. Select your `nivra-static` folder from Files app
7. Wait 10-30 seconds
8. Your site is LIVE! 🎉

### Step 3: Get Your URL
- Netlify will give you a free URL like:
  `https://nivra-123456.netlify.app`
- You can change it in settings

---

## 🌐 Alternative: GitHub Pages

### Step 1: Create GitHub Account
1. Go to [github.com](https://github.com) on Safari
2. Sign up (free)

### Step 2: Create Repository
1. Tap **"+"** → **"New repository"**
2. Name it `nivra-store`
3. Make it **Public**
4. Tap **"Create repository"**

### Step 3: Upload Files
1. In your new repo, tap **"uploading an existing file"**
2. Tap **"Choose your files"**
3. Select ALL files from `nivra-static` folder
4. Tap **"Commit changes"**

### Step 4: Enable GitHub Pages
1. Go to repo **Settings** (tab at top)
2. Scroll down to **"Pages"**
3. Under **"Source"**, select **"Deploy from a branch"**
4. Select **"main"** branch
5. Tap **"Save"**
6. Wait 2-5 minutes
7. Your site will be at:
   `https://yourusername.github.io/nivra-store`

---

## 📦 Alternative: Surge.sh (Super Fast)

### If you have Node.js on your computer:
```bash
npm install -g surge
cd nivra-static
surge
```

### On mobile (using Termux):
```bash
npm install -g surge
cd nivra-static
surge
# Follow prompts
```

---

## 🔥 Alternative: Tiiny.host (Easiest for Mobile)

1. Go to [tiiny.host](https://tiiny.host) on Safari
2. No signup needed!
3. Tap **"Upload ZIP"**
4. Select your `nivra-static.zip`
5. Choose a subdomain name
6. Tap **"Upload"**
7. Done! Your site is live instantly!

---

## 📲 Alternative: Direct Preview (No Internet Needed)

### On iPhone:
1. Open **Files app**
2. Go to `nivra-static` folder
3. Tap `index.html`
4. It opens in Safari!
5. **Note**: Cart won't work (needs internet for images)

### On Android:
1. Open file manager
2. Find `nivra-static` folder
3. Tap `index.html`
4. Choose browser to open

---

## ✅ Checklist Before Deploying

- [ ] All HTML files are in the folder
- [ ] `css/style.css` exists
- [ ] `js/app.js` exists
- [ ] Images folder exists (or using online URLs)
- [ ] Tested locally by opening `index.html`

---

## 🎉 After Deployment

### Custom Domain (Optional):
- Buy domain from Namecheap/GoDaddy
- Connect it in Netlify/GitHub settings
- Usually costs $10-15/year

### Share Your Site:
- Copy the URL
- Share on WhatsApp, Instagram, etc.
- Add to your bio/linktree

---

## 🆘 Troubleshooting

### "Page Not Found" on Netlify?
- Make sure `index.html` is in the ROOT folder
- Don't upload the ZIP file itself
- Upload the EXTRACTED folder contents

### Images Not Loading?
- The demo uses online images from Unsplash
- For your real products, upload images to:
  - [imgur.com](https://imgur.com) (free)
  - [cloudinary.com](https://cloudinary.com) (free tier)
  - Or use your own hosting

### Cart Not Working?
- Cart uses `localStorage` (browser storage)
- Works on same device/browser only
- For real e-commerce, you need a backend

---

## 📞 Need Help?

Contact: hello@nivra.com

## 🎨 Want to Customize?

Edit these files:
- `index.html` - Home page content
- `css/style.css` - Colors, fonts, spacing
- `js/app.js` - Products, prices, logic

---

**Good luck with your store! 🔥**
