-- =============================================
-- NIVRA DATABASE SCHEMA
-- Run this in Supabase SQL Editor
-- =============================================

-- 1. CUSTOMERS
CREATE TABLE IF NOT EXISTS customers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT,
  phone TEXT NOT NULL,
  address TEXT,
  city TEXT,
  governorate TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. PRODUCTS
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  currency TEXT DEFAULT 'LE',
  description TEXT,
  category TEXT,
  sizes TEXT[],
  colors TEXT[],
  images TEXT[],
  sold_out BOOLEAN DEFAULT FALSE,
  featured BOOLEAN DEFAULT FALSE,
  stock INT DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. ORDERS
CREATE TABLE IF NOT EXISTS orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID REFERENCES customers(id),
  status TEXT DEFAULT 'pending',
  payment_method TEXT,
  subtotal NUMERIC NOT NULL,
  cod_fee NUMERIC DEFAULT 0,
  total NUMERIC NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. ORDER ITEMS
CREATE TABLE IF NOT EXISTS order_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT REFERENCES products(id),
  product_name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  quantity INT NOT NULL,
  size TEXT,
  color TEXT
);

-- 5. CONTACT MESSAGES
CREATE TABLE IF NOT EXISTS contact_messages (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  subject TEXT,
  message TEXT NOT NULL,
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- DISABLE RLS (for simplicity - static site)
-- =============================================
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;

-- Allow public to INSERT (checkout & contact form)
CREATE POLICY "allow_insert_customers" ON customers FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "allow_insert_orders" ON orders FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "allow_insert_order_items" ON order_items FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "allow_insert_contact" ON contact_messages FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "allow_read_products" ON products FOR SELECT TO anon USING (true);

-- Allow admin to read everything (use service role key in admin panel)
CREATE POLICY "allow_all_customers" ON customers FOR ALL TO service_role USING (true);
CREATE POLICY "allow_all_orders" ON orders FOR ALL TO service_role USING (true);
CREATE POLICY "allow_all_order_items" ON order_items FOR ALL TO service_role USING (true);
CREATE POLICY "allow_all_contact" ON contact_messages FOR ALL TO service_role USING (true);
CREATE POLICY "allow_all_products" ON products FOR ALL TO service_role USING (true);

-- =============================================
-- SEED PRODUCTS FROM APP DATA
-- =============================================
INSERT INTO products (id, name, price, description, category, sizes, colors, images, sold_out, featured) VALUES
('tank-top-black','Essential Tank Top',199,'Premium cotton tank top. Minimal design, maximum comfort.','Tops',ARRAY['S','M','L','XL'],ARRAY['Black','White'],ARRAY['https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop'],true,true),
('denim-jeans-black','Wide Leg Denim',349,'High-quality black denim with wide leg cut.','Bottoms',ARRAY['28','30','32','34','36'],ARRAY['Black','Indigo'],ARRAY['https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?w=600&h=800&fit=crop'],true,true),
('tee-white','Classic Tee',179,'Heavyweight cotton t-shirt with dropped shoulders.','Tops',ARRAY['S','M','L','XL','XXL'],ARRAY['White','Black','Grey'],ARRAY['https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop'],true,true),
('leather-jacket','Biker Leather Jacket',899,'Premium faux leather biker jacket with silver hardware.','Outerwear',ARRAY['S','M','L','XL'],ARRAY['Black'],ARRAY['https://images.unsplash.com/photo-1551028919-ac76c9028d1b?w=600&h=800&fit=crop'],true,true),
('hoodie-oversized','Oversized Hoodie',299,'Ultra-comfortable oversized hoodie with kangaroo pocket.','Tops',ARRAY['S','M','L','XL'],ARRAY['Black','Grey','Beige'],ARRAY['https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop'],false,false),
('cargo-pants','Cargo Pants',259,'Utility cargo pants with multiple pockets.','Bottoms',ARRAY['S','M','L','XL'],ARRAY['Khaki','Black','Olive'],ARRAY['https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&h=800&fit=crop'],false,false),
('jp-wave-hoodie','Wave Hoodie 波',280,'Oversized hoodie with Japanese wave print.','Japanese',ARRAY['S','M','L','XL'],ARRAY['Black','Navy'],ARRAY['https://images.unsplash.com/photo-1559582798-678dfc71ccd8?w=600&h=800&fit=crop'],false,false),
('jp-sakura-tee','Sakura Tee 桜',180,'Cherry blossom graphic tee.','Japanese',ARRAY['S','M','L','XL'],ARRAY['White','Pink','Black'],ARRAY['https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop'],false,false),
('jp-kanji-jacket','Kanji Bomber 漢字',350,'Bomber jacket with Japanese kanji print.','Japanese',ARRAY['S','M','L','XL'],ARRAY['Black','Olive'],ARRAY['https://images.unsplash.com/photo-1551028919-ac76c9028d1b?w=600&h=800&fit=crop'],false,false),
('jp-oni-mask','Oni Mask Tee 鬼',200,'Demon mask graphic tee.','Japanese',ARRAY['S','M','L','XL'],ARRAY['Black','Red'],ARRAY['https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&h=800&fit=crop'],false,false),
('sp-basic-white','Basic White Tee',150,'Clean white essential tee. No prints, pure minimal.','Simple',ARRAY['S','M','L','XL'],ARRAY['White'],ARRAY['https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop'],false,false),
('sp-black-hoodie','Essential Black Hoodie',250,'Plain black hoodie. Clean lines, no logos.','Simple',ARRAY['S','M','L','XL'],ARRAY['Black'],ARRAY['https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop'],false,false),
('sp-gray-pants','Minimal Gray Pants',200,'Simple gray cargo pants.','Simple',ARRAY['S','M','L','XL'],ARRAY['Gray'],ARRAY['https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&h=800&fit=crop'],false,false),
('lx-gold-shirt','Gold Accent Shirt',450,'Premium shirt with gold thread details.','Luxury',ARRAY['S','M','L','XL'],ARRAY['Black','White'],ARRAY['https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&h=800&fit=crop'],false,false),
('lx-velvet-jacket','Velvet Bomber',650,'Velvet bomber jacket with gold zipper.','Luxury',ARRAY['S','M','L','XL'],ARRAY['Black','Burgundy'],ARRAY['https://images.unsplash.com/photo-1507679799987-c737795bccf8?w=600&h=800&fit=crop'],false,false),
('lx-leather-pants','Leather Street Pants',550,'Genuine leather pants. Streetwear meets luxury.','Luxury',ARRAY['S','M','L','XL'],ARRAY['Black'],ARRAY['https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&h=800&fit=crop'],false,false)
ON CONFLICT (id) DO NOTHING;
