// =============================================
// NIVRA - Database Integration
// =============================================

// Generate order number: NIVRA-YYYYMMDD-XXXX
function generateOrderNumber() {
  const date = new Date();
  const d = date.toISOString().slice(0,10).replace(/-/g,'');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `NIVRA-${d}-${rand}`;
}

// =============================================
// SAVE ORDER TO DATABASE
// =============================================
async function saveOrderToDatabase(formData, cartItems, total, paymentMethod, codFee) {
  try {
    // 1. Find or create customer
    const existingCustomers = await db.select('customers', `phone=eq.${encodeURIComponent(formData.phone)}&limit=1`);
    
    let customerId;
    if (existingCustomers.length > 0) {
      // Update existing customer
      customerId = existingCustomers[0].id;
      await db.update('customers', customerId, {
        first_name: formData.firstName,
        last_name: formData.lastName,
        email: formData.email || null,
        address: formData.address,
        city: formData.city,
        governorate: formData.governorate,
        postal_code: formData.postalCode || null
      });
    } else {
      // Create new customer
      const [newCustomer] = await db.insert('customers', {
        first_name: formData.firstName,
        last_name: formData.lastName,
        email: formData.email || null,
        phone: formData.phone,
        address: formData.address,
        city: formData.city,
        governorate: formData.governorate,
        postal_code: formData.postalCode || null
      });
      customerId = newCustomer.id;
    }

    // 2. Create order
    const orderNumber = generateOrderNumber();
    const [order] = await db.insert('orders', {
      order_number: orderNumber,
      customer_id: customerId,
      customer_name: `${formData.firstName} ${formData.lastName}`,
      customer_phone: formData.phone,
      customer_email: formData.email || null,
      address: formData.address,
      city: formData.city,
      governorate: formData.governorate,
      payment_method: paymentMethod,
      subtotal: total - codFee,
      cod_fee: codFee,
      total: total,
      status: 'pending'
    });

    // 3. Create order items
    const orderItemsData = cartItems.map(item => ({
      order_id: order.id,
      product_id: item.id,
      product_name: item.name,
      size: item.size,
      color: item.color,
      price: item.price,
      quantity: item.quantity,
      subtotal: item.price * item.quantity
    }));

    await db.insert('order_items', orderItemsData);

    // Save order number for success page
    localStorage.setItem('nivra-last-order-number', orderNumber);
    localStorage.setItem('nivra-last-order', total);

    console.log('✅ Order saved:', orderNumber);
    return { success: true, orderNumber };

  } catch (err) {
    console.error('❌ DB Error:', err);
    // Still proceed - don't block checkout on DB error
    localStorage.setItem('nivra-last-order', total);
    return { success: false, error: err };
  }
}

// =============================================
// SAVE CONTACT MESSAGE TO DATABASE
// =============================================
async function saveContactMessage(name, email, subject, message) {
  try {
    await db.insert('contact_messages', { name, email, subject, message, status: 'unread' });
    return true;
  } catch (err) {
    console.error('❌ Contact message error:', err);
    return false;
  }
}
