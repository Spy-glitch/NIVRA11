// NIVRA - Static JavaScript

// ===== PRODUCT DATA (single source of truth) =====
const products = [
  // Streetwear Original
  {
    id: "tank-top-black",
    name: "Essential Tank Top",
    price: 199,
    currency: "LE",
    description: "Premium cotton tank top. Minimal design, maximum comfort.",
    images: ["https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "White"],
    category: "Tops",
    soldOut: true,
    featured: true,
  },
  {
    id: "denim-jeans-black",
    name: "Wide Leg Denim",
    price: 349,
    currency: "LE",
    description: "High-quality black denim with wide leg cut. Streetwear essential.",
    images: ["https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?w=600&h=800&fit=crop"],
    sizes: ["28", "30", "32", "34", "36"],
    colors: ["Black", "Indigo"],
    category: "Bottoms",
    soldOut: true,
    featured: true,
  },
  {
    id: "tee-white",
    name: "Classic Tee",
    price: 179,
    currency: "LE",
    description: "Heavyweight cotton t-shirt with dropped shoulders.",
    images: ["https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Black", "Grey"],
    category: "Tops",
    soldOut: true,
    featured: true,
  },
  {
    id: "leather-jacket",
    name: "Biker Leather Jacket",
    price: 899,
    currency: "LE",
    description: "Premium faux leather biker jacket with silver hardware.",
    images: ["https://images.unsplash.com/photo-1551028919-ac76c9028d1b?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black"],
    category: "Outerwear",
    soldOut: true,
    featured: true,
  },
  {
    id: "hoodie-oversized",
    name: "Oversized Hoodie",
    price: 299,
    currency: "LE",
    description: "Ultra-comfortable oversized hoodie with kangaroo pocket.",
    images: ["https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Grey", "Beige"],
    category: "Tops",
    soldOut: false,
    featured: false,
  },
  {
    id: "cargo-pants",
    name: "Cargo Pants",
    price: 259,
    currency: "LE",
    description: "Utility cargo pants with multiple pockets.",
    images: ["https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Khaki", "Black", "Olive"],
    category: "Bottoms",
    soldOut: false,
    featured: false,
  },
  // Japanese Streetwear
  {
    id: "jp-wave-hoodie",
    name: "Wave Hoodie 波",
    price: 280,
    currency: "LE",
    description: "Oversized hoodie with Japanese wave print. 日本の波デザイン.",
    images: ["https://images.unsplash.com/photo-1559582798-678dfc71ccd8?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Navy"],
    category: "Japanese",
    soldOut: false,
    featured: false,
  },
  {
    id: "jp-sakura-tee",
    name: "Sakura Tee 桜",
    price: 180,
    currency: "LE",
    description: "Cherry blossom graphic tee. 桜の花デザイン.",
    images: ["https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["White", "Pink", "Black"],
    category: "Japanese",
    soldOut: false,
    featured: false,
  },
  {
    id: "jp-kanji-jacket",
    name: "Kanji Bomber 漢字",
    price: 350,
    currency: "LE",
    description: "Bomber jacket with Japanese kanji print. 漢字プリント.",
    images: ["https://images.unsplash.com/photo-1551028919-ac76c9028d1b?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Olive"],
    category: "Japanese",
    soldOut: false,
    featured: false,
  },
  {
    id: "jp-oni-mask",
    name: "Oni Mask Tee 鬼",
    price: 200,
    currency: "LE",
    description: "Demon mask graphic tee. 鬼マスクデザイン.",
    images: ["https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Red"],
    category: "Japanese",
    soldOut: false,
    featured: false,
  },
  // Simple/Minimal
  {
    id: "sp-basic-white",
    name: "Basic White Tee",
    price: 150,
    currency: "LE",
    description: "Clean white essential tee. No prints, pure minimal.",
    images: ["https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["White"],
    category: "Simple",
    soldOut: false,
    featured: false,
  },
  {
    id: "sp-black-hoodie",
    name: "Essential Black Hoodie",
    price: 250,
    currency: "LE",
    description: "Plain black hoodie. Clean lines, no logos.",
    images: ["https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black"],
    category: "Simple",
    soldOut: false,
    featured: false,
  },
  {
    id: "sp-gray-pants",
    name: "Minimal Gray Pants",
    price: 200,
    currency: "LE",
    description: "Simple gray cargo pants. Utility meets minimal.",
    images: ["https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Gray"],
    category: "Simple",
    soldOut: false,
    featured: false,
  },
  // Luxury
  {
    id: "lx-gold-shirt",
    name: "Gold Accent Shirt",
    price: 450,
    currency: "LE",
    description: "Premium shirt with gold thread details. Elevated streetwear.",
    images: ["https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "White"],
    category: "Luxury",
    soldOut: false,
    featured: false,
  },
  {
    id: "lx-velvet-jacket",
    name: "Velvet Bomber",
    price: 650,
    currency: "LE",
    description: "Velvet bomber jacket with gold zipper. Premium materials.",
    images: ["https://images.unsplash.com/photo-1507679799987-c737795bccf8?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black", "Burgundy"],
    category: "Luxury",
    soldOut: false,
    featured: false,
  },
  {
    id: "lx-leather-pants",
    name: "Leather Street Pants",
    price: 550,
    currency: "LE",
    description: "Genuine leather pants. Streetwear meets luxury.",
    images: ["https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&h=800&fit=crop"],
    sizes: ["S", "M", "L", "XL"],
    colors: ["Black"],
    category: "Luxury",
    soldOut: false,
    featured: false,
  },
];

// ===== NAVBAR INJECTION (single source — fixes duplication) =====
function injectNavbar(type = 'full') {
  const currentYear = new Date().getFullYear();

  const fullNav = `
    <nav class="navbar">
      <div class="nav-left">
        <button class="nav-btn" onclick="toggleMenu()" aria-label="Menu">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
            <path d="M3 12h18M3 6h18M3 18h18"/>
          </svg>
        </button>
        <button class="nav-btn" onclick="toggleSearch()" aria-label="Search">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
          </svg>
        </button>
      </div>
      <a href="index.html" class="nav-logo">NIVRA</a>
      <div class="nav-right">
        <a href="account.html" class="nav-btn" aria-label="Account">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
          </svg>
        </a>
        <button class="nav-btn" onclick="openCart()" aria-label="Cart" style="position: relative;">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 01-8 0"/>
          </svg>
          <span class="cart-badge" style="display: none;">0</span>
        </button>
      </div>
    </nav>
    <div class="mobile-menu" id="mobile-menu">
      <a href="index.html" onclick="closeMenu()">Home</a>
      <a href="shop.html" onclick="closeMenu()">Shop</a>
      <a href="new-arrivals.html" onclick="closeMenu()">New Arrivals</a>
      <a href="about.html" onclick="closeMenu()">About</a>
      <a href="contact.html" onclick="closeMenu()">Contact</a>
    </div>
    <div class="search-bar" id="search-bar">
      <input type="text" id="search-input" placeholder="Search products..." oninput="handleSearch(this.value)">
    </div>
    <div id="search-results-dropdown" class="search-dropdown" style="display:none;"></div>
    <div class="cart-overlay" id="cart-overlay" onclick="closeCart()"></div>
    <div class="cart-sidebar" id="cart-sidebar">
      <div class="cart-header">
        <div class="cart-title">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
          </svg>
          <span>Your Cart (<span id="cart-count">0</span>)</span>
        </div>
        <button class="nav-btn" onclick="closeCart()" style="color: var(--nivra-brown);">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 6L6 18M6 6l12 12"/>
          </svg>
        </button>
      </div>
      <div class="cart-items" id="cart-items">
        <div class="cart-empty">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
          </svg>
          <p>Your cart is empty</p>
          <a href="shop.html" onclick="closeCart()" style="color: var(--nivra-brown); text-decoration: underline;">Continue Shopping</a>
        </div>
      </div>
      <div class="cart-footer" id="cart-footer" style="display: none;">
        <div class="cart-total">
          <span>Subtotal</span>
          <span id="cart-total-price">LE 0</span>
        </div>
        <p style="font-size: 13px; color: var(--nivra-light); margin-bottom: 15px;">Shipping and taxes calculated at checkout</p>
        <a href="checkout.html" class="checkout-btn" onclick="closeCart()">Proceed to Checkout</a>
        <a href="shop.html" class="continue-btn" onclick="closeCart()">Continue Shopping</a>
      </div>
    </div>`;

  const simpleNav = `
    <nav class="navbar">
      <div class="nav-left">
        <a href="javascript:history.back()" class="nav-btn" aria-label="Back">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M19 12H5M12 19l-7-7 7-7"/>
          </svg>
        </a>
      </div>
      <a href="index.html" class="nav-logo">NIVRA</a>
      <div class="nav-right"></div>
    </nav>`;

  const navHTML = type === 'simple' ? simpleNav : fullNav;
  document.body.insertAdjacentHTML('afterbegin', navHTML);

  // inject footer too
  const footerHTML = `
    <footer class="footer">
      <div class="footer-grid">
        <div class="footer-brand">
          <h3>NIVRA</h3>
          <p>Premium streetwear for those who dare to stand out. Wear your truth.</p>
        </div>
        <div class="footer-links">
          <h4>Quick Links</h4>
          <a href="shop.html">Shop</a>
          <a href="new-arrivals.html">New Arrivals</a>
          <a href="track.html">Track Order</a>
          <a href="about.html">About</a>
          <a href="contact.html">Contact</a>
        </div>
        <div class="footer-links">
          <h4>Support</h4>
          <a href="javascript:void(0)" onclick="alert('FAQ coming soon!')">FAQ</a>
          <a href="javascript:void(0)" onclick="alert('Free shipping across Egypt within 2-3 business days.')">Shipping</a>
          <a href="javascript:void(0)" onclick="alert('30-day hassle-free returns. Contact us on WhatsApp.')">Returns</a>
          <a href="size-guide.html">Size Guide</a>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; ${currentYear} NIVRA. All rights reserved.</p>
      </div>
    </footer>`;

  const footerPlaceholder = document.getElementById('footer-placeholder');
  if (footerPlaceholder) footerPlaceholder.outerHTML = footerHTML;

  // WhatsApp float button (not on checkout/success)
  const skipWa = ['checkout.html','success.html'].some(p => window.location.pathname.includes(p));
  if (!skipWa) {
    document.body.insertAdjacentHTML('beforeend', `
      <a href="https://wa.me/201099938634" target="_blank" class="whatsapp-float" aria-label="WhatsApp">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </a>
      <div class="toast" id="toast"></div>
    `);
  }
}

// ===== CART =====
let cart = JSON.parse(localStorage.getItem('nivra-cart')) || [];

function saveCart() {
  localStorage.setItem('nivra-cart', JSON.stringify(cart));
  updateCartUI();
}

function addToCart(productId, size, color, qty = 1) {
  const product = products.find(p => p.id === productId);
  if (!product) return;

  const existing = cart.find(item =>
    item.id === productId && item.size === size && item.color === color
  );

  if (existing) {
    existing.quantity += qty;
  } else {
    cart.push({
      id: productId,
      name: product.name,
      price: product.price,
      currency: product.currency,
      image: product.images[0],
      size,
      color,
      quantity: qty
    });
  }

  saveCart();
  openCart();
}

function removeFromCart(id, size, color) {
  cart = cart.filter(item =>
    !(item.id === id && item.size === size && item.color === color)
  );
  saveCart();
}

function updateQuantity(id, size, color, qty) {
  if (qty <= 0) { removeFromCart(id, size, color); return; }
  const item = cart.find(item =>
    item.id === id && item.size === size && item.color === color
  );
  if (item) { item.quantity = qty; saveCart(); }
}

function getCartTotal() {
  return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function getCartCount() {
  return cart.reduce((sum, item) => sum + item.quantity, 0);
}

function clearCart() {
  cart = [];
  saveCart();
}

// ===== UI UPDATES =====
function updateCartUI() {
  const badges = document.querySelectorAll('.cart-badge');
  const count = getCartCount();
  badges.forEach(badge => {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  });
  const countEl = document.getElementById('cart-count');
  if (countEl) countEl.textContent = count;
  renderCartItems();
}

function renderCartItems() {
  const container = document.getElementById('cart-items');
  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = `
      <div class="cart-empty">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
        </svg>
        <p>Your cart is empty</p>
        <a href="shop.html" onclick="closeCart()" style="color: var(--nivra-brown); text-decoration: underline;">Continue Shopping</a>
      </div>`;
    const footer = document.getElementById('cart-footer');
    if (footer) footer.style.display = 'none';
    return;
  }

  container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" class="cart-item-img">
      <div class="cart-item-info">
        <div style="display: flex; justify-content: space-between; align-items: start;">
          <div>
            <div class="cart-item-name">${item.name}</div>
            <div class="cart-item-meta">Size: ${item.size} | Color: ${item.color}</div>
          </div>
          <button class="remove-btn" onclick="removeFromCart('${item.id}', '${item.size}', '${item.color}')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
            </svg>
          </button>
        </div>
        <div class="cart-item-actions">
          <div class="qty-controls">
            <button class="qty-btn" onclick="updateQuantity('${item.id}', '${item.size}', '${item.color}', ${item.quantity - 1})">−</button>
            <span>${item.quantity}</span>
            <button class="qty-btn" onclick="updateQuantity('${item.id}', '${item.size}', '${item.color}', ${item.quantity + 1})">+</button>
          </div>
          <div class="cart-item-price">${item.currency} ${item.price * item.quantity}</div>
        </div>
      </div>
    </div>`).join('');

  const footer = document.getElementById('cart-footer');
  if (footer) footer.style.display = 'block';
  const totalEl = document.getElementById('cart-total-price');
  if (totalEl) totalEl.textContent = `LE ${getCartTotal()}`;
}

// ===== CART TOGGLE =====
function openCart() {
  document.getElementById('cart-overlay')?.classList.add('active');
  document.getElementById('cart-sidebar')?.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cart-overlay')?.classList.remove('active');
  document.getElementById('cart-sidebar')?.classList.remove('active');
  document.body.style.overflow = '';
}

// ===== MOBILE MENU =====
function toggleMenu() {
  document.getElementById('mobile-menu')?.classList.toggle('active');
}

function closeMenu() {
  document.getElementById('mobile-menu')?.classList.remove('active');
}

// ===== SEARCH (now actually works) =====
function toggleSearch() {
  const bar = document.getElementById('search-bar');
  if (!bar) return;
  bar.classList.toggle('active');
  if (bar.classList.contains('active')) {
    document.getElementById('search-input')?.focus();
  } else {
    const dropdown = document.getElementById('search-results-dropdown');
    if (dropdown) dropdown.style.display = 'none';
  }
}

function handleSearch(query) {
  const dropdown = document.getElementById('search-results-dropdown');
  if (!dropdown) return;

  const q = query.trim().toLowerCase();
  if (!q) { dropdown.style.display = 'none'; return; }

  const results = products.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.category.toLowerCase().includes(q) ||
    p.description.toLowerCase().includes(q)
  ).slice(0, 6);

  if (results.length === 0) {
    dropdown.innerHTML = `<div class="search-no-results">No products found for "${query}"</div>`;
    dropdown.style.display = 'block';
    return;
  }

  dropdown.innerHTML = results.map(p => `
    <a href="product.html?id=${p.id}" class="search-result-item" onclick="closeSearchDropdown()">
      <img src="${p.images[0]}" alt="${p.name}">
      <div>
        <div class="search-result-name">${p.name}</div>
        <div class="search-result-price">${p.soldOut ? 'Sold Out' : `LE ${p.price}`}</div>
      </div>
    </a>`).join('');
  dropdown.style.display = 'block';
}

function closeSearchDropdown() {
  const dropdown = document.getElementById('search-results-dropdown');
  const bar = document.getElementById('search-bar');
  if (dropdown) dropdown.style.display = 'none';
  if (bar) bar.classList.remove('active');
}

// ===== RENDER PRODUCTS =====
function renderProducts(containerId, productList, startDelay = 0) {
  const container = document.getElementById(containerId);
  if (!container) return;

  if (productList.length === 0) {
    container.innerHTML = '<p style="text-align:center; color: var(--nivra-light); padding: 40px;">No products found.</p>';
    return;
  }

  container.innerHTML = productList.map((product, index) => `
    <div class="product-card fade-in" style="animation-delay: ${(index + startDelay) * 0.1}s">
      <a href="product.html?id=${product.id}">
        <div class="product-image">
          <img src="${product.images[0]}" alt="${product.name}" loading="lazy">
          ${product.soldOut ? '<div class="sold-out-badge">Sold Out</div>' : ''}
          ${!product.soldOut ? `
            <button class="quick-add" onclick="event.preventDefault(); event.stopPropagation(); quickAdd('${product.id}')">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
              </svg>
            </button>` : ''}
        </div>
        <div class="product-info">
          <div class="product-name">${product.name}</div>
          <div class="product-price">${product.soldOut ? '<span style="color:var(--nivra-light)">Sold Out</span>' : `${product.currency} ${product.price.toFixed(2)}`}</div>
        </div>
      </a>
    </div>`).join('');
}

function quickAdd(productId) {
  const product = products.find(p => p.id === productId);
  if (!product || product.soldOut) return;
  addToCart(productId, product.sizes[0], product.colors[0], 1);
}

// ===== PRODUCT DETAIL =====
function loadProductDetail() {
  const params = new URLSearchParams(window.location.search);
  const productId = params.get('id');
  const product = products.find(p => p.id === productId) || products[0];

  if (!product) { window.location.href = 'shop.html'; return; }

  document.title = `${product.name} - NIVRA`;

  // Breadcrumb
  const breadcrumb = document.getElementById('breadcrumb-name');
  if (breadcrumb) breadcrumb.textContent = product.name;

  // Meta description
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) metaDesc.setAttribute('content', product.description);

  document.getElementById('main-image').src = product.images[0];
  document.getElementById('main-image').alt = product.name;

  const thumbsContainer = document.getElementById('thumbnails');
  if (thumbsContainer) {
    thumbsContainer.innerHTML = product.images.map((img, idx) => `
      <div class="thumb ${idx === 0 ? 'active' : ''}" onclick="changeImage('${img}', this)">
        <img src="${img}" alt="${product.name} ${idx + 1}">
      </div>`).join('');
  }

  document.getElementById('product-name').textContent = product.name;
  document.getElementById('product-price').textContent = `${product.currency} ${product.price.toFixed(2)}`;
  document.getElementById('product-desc').textContent = product.description;

  const catEl = document.getElementById('product-category');
  if (catEl) catEl.textContent = product.category;

  const stockEl = document.getElementById('product-stock');
  if (stockEl) {
    stockEl.textContent = product.soldOut ? 'Sold Out' : 'In Stock';
    stockEl.style.color = product.soldOut ? '#c0392b' : '#27ae60';
  }

  const colorsContainer = document.getElementById('color-options');
  if (colorsContainer) {
    colorsContainer.innerHTML = product.colors.map((color, idx) => `
      <button class="option-btn ${idx === 0 ? 'active' : ''}" data-color="${color}" onclick="selectColor(this)">${color}</button>`).join('');
  }

  const sizesContainer = document.getElementById('size-options');
  if (sizesContainer) {
    sizesContainer.innerHTML = product.sizes.map((size, idx) => `
      <button class="option-btn ${idx === 0 ? 'active' : ''}" data-size="${size}" onclick="selectSize(this)">${size}</button>`).join('');
  }

  const addBtn = document.getElementById('add-to-cart-btn');
  if (product.soldOut && addBtn) {
    addBtn.disabled = true;
    addBtn.textContent = 'Sold Out';
    addBtn.style.opacity = '0.6';
    addBtn.style.cursor = 'not-allowed';
  }

  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);
  renderProducts('related-products', related);
}

function changeImage(src, thumb) {
  document.getElementById('main-image').src = src;
  document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
  thumb.classList.add('active');
}

function selectColor(btn) {
  document.querySelectorAll('#color-options .option-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function selectSize(btn) {
  document.querySelectorAll('#size-options .option-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
}

function addToCartFromDetail() {
  const params = new URLSearchParams(window.location.search);
  const productId = params.get('id');
  const product = products.find(p => p.id === productId);
  if (!product || product.soldOut) return;

  const color = document.querySelector('#color-options .option-btn.active')?.dataset.color || product.colors[0];
  const size = document.querySelector('#size-options .option-btn.active')?.dataset.size || product.sizes[0];

  addToCart(productId, size, color, 1);

  const msg = document.getElementById('success-msg');
  if (msg) {
    msg.style.display = 'flex';
    setTimeout(() => msg.style.display = 'none', 2000);
  }
}

// ===== SHOP PAGE =====
let currentCategory = 'All';
let currentSort = 'featured';

function initShop() {
  filterProducts();
}

function filterProducts() {
  let filtered = currentCategory === 'All'
    ? [...products]
    : products.filter(p => p.category === currentCategory);

  switch (currentSort) {
    case 'price-asc': filtered.sort((a, b) => a.price - b.price); break;
    case 'price-desc': filtered.sort((a, b) => b.price - a.price); break;
    case 'name-asc': filtered.sort((a, b) => a.name.localeCompare(b.name)); break;
  }

  renderProducts('shop-products', filtered);

  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.category === currentCategory);
  });
}

function setCategory(cat) {
  currentCategory = cat;
  filterProducts();
}

function setSort(sort) {
  currentSort = sort;
  filterProducts();
}

// ===== CHECKOUT =====
function loadCheckout() {
  if (cart.length === 0) { window.location.href = 'shop.html'; return; }

  const container = document.getElementById('order-items');
  if (container) {
    container.innerHTML = cart.map(item => `
      <div class="order-item">
        <img src="${item.image}" alt="${item.name}">
        <div class="order-item-info">
          <h4>${item.name}</h4>
          <p>${item.size} / ${item.color}</p>
          <p>${item.currency} ${item.price} x ${item.quantity}</p>
        </div>
        <div class="order-item-price">${item.currency} ${item.price * item.quantity}</div>
      </div>`).join('');
  }

  updateCheckoutTotal();
}

function updateCheckoutTotal() {
  const subtotal = getCartTotal();
  const paymentMethod = document.querySelector('.payment-option.active')?.dataset.method || 'fawry';
  const codFee = paymentMethod === 'cod' ? 50 : 0;

  let discountAmt = 0;
  if (appliedDiscount) {
    discountAmt = appliedDiscount.type === 'percent'
      ? Math.round(subtotal * appliedDiscount.value / 100)
      : appliedDiscount.value;
  }

  const total = subtotal - discountAmt + codFee;

  const subtotalEl = document.getElementById('subtotal');
  const codFeeEl = document.getElementById('cod-fee');
  const codFeeAmtEl = document.getElementById('cod-fee-amount');
  const discountRowEl = document.getElementById('discount-row');
  const discountAmtEl = document.getElementById('discount-amount');
  const totalEl = document.getElementById('total');
  const placeBtn = document.getElementById('place-order-btn');

  if (subtotalEl) subtotalEl.textContent = `LE ${subtotal}`;
  if (codFeeEl) codFeeEl.style.display = codFee > 0 ? 'flex' : 'none';
  if (codFeeAmtEl && codFee > 0) codFeeAmtEl.textContent = `LE ${codFee}`;
  if (discountRowEl) discountRowEl.style.display = discountAmt > 0 ? 'flex' : 'none';
  if (discountAmtEl && discountAmt > 0) discountAmtEl.textContent = `-LE ${discountAmt}`;
  if (totalEl) totalEl.textContent = `LE ${total}`;
  if (placeBtn) placeBtn.textContent = `Place Order - LE ${total}`;
}

function selectPayment(method) {
  document.querySelectorAll('.payment-option').forEach(opt => {
    opt.classList.toggle('active', opt.dataset.method === method);
  });

  const notes = {
    fawry: 'You will receive a Fawry code after placing your order. Pay at any Fawry outlet within 48 hours.',
    vodafone: 'You will receive payment instructions via SMS. Complete the transfer using your Vodafone Cash wallet.',
    telda: 'You will be redirected to Telda to complete your payment securely.',
    cod: 'Pay when your order is delivered. Additional LE 50 COD fee applies.'
  };

  const noteEl = document.getElementById('payment-note');
  if (noteEl) noteEl.textContent = notes[method] || '';
  updateCheckoutTotal();
}

function handleCheckout(e) {
  e.preventDefault();

  const btn = document.getElementById('place-order-btn');
  btn.disabled = true;
  btn.innerHTML = `
    <svg class="spin" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M12 2v4m0 12v4m-4-8H4m16 0h-4m-2.5-5.5L7 17m10-10L7 7"/>
    </svg>
    Processing...`;

  const form = e.target;
  const formData = {
    firstName: form.firstName?.value || '',
    lastName: form.lastName?.value || '',
    email: form.email?.value || '',
    phone: form.phone?.value || '',
    address: form.address?.value || '',
    city: form.city?.value || '',
    governorate: form.governorate?.value || '',
    postalCode: form.postalCode?.value || ''
  };

  const paymentMethod = document.querySelector('.payment-option.active')?.dataset.method || 'fawry';
  const codFee = paymentMethod === 'cod' ? 50 : 0;
  const total = getCartTotal() + codFee;
  const cartSnapshot = [...cart];

  localStorage.setItem('nivra-last-payment', paymentMethod);
  saveOrderToDatabase(formData, cartSnapshot, total, paymentMethod, codFee).then(() => {
    clearCart();
    window.location.href = 'success.html';
  });
}

// ===== SUCCESS PAGE =====
function loadSuccess() {
  const total = localStorage.getItem('nivra-last-order') || '0';
  const orderNum = localStorage.getItem('nivra-last-order-number') || '—';
  const paymentMethod = localStorage.getItem('nivra-last-payment') || 'fawry';

  const el = document.getElementById('success-total');
  if (el) el.textContent = `LE ${total}`;

  const numEl = document.getElementById('success-order-number');
  if (numEl) numEl.textContent = orderNum;

  // Payment instructions
  const instructions = {
    fawry: `💳 Please pay via Fawry\nSend LE ${total} to number: 01099938634\nReference: ${orderNum}`,
    vodafone: `📱 Please pay via Vodafone Cash\nSend LE ${total} to number: 01099938634\nReference: ${orderNum}`,
    telda: `💜 Please pay via Telda\nSend LE ${total} to Telda ID: nivra11\nReference: ${orderNum}`,
    cod: `🚚 Cash on Delivery\nPay LE ${total} when your order arrives.\nWe'll call you to confirm the delivery time.`
  };

  const instrEl = document.getElementById('payment-instructions-text');
  if (instrEl) {
    const text = instructions[paymentMethod] || instructions.fawry;
    instrEl.innerHTML = text.replace(/\n/g, '<br>');
  }

  // WhatsApp message
  const waMessages = {
    fawry: `Hi NIVRA! I just placed order ${orderNum} for LE ${total}. I'll pay via Fawry to 01099938634.`,
    vodafone: `Hi NIVRA! I just placed order ${orderNum} for LE ${total}. I'll pay via Vodafone Cash to 01099938634.`,
    telda: `Hi NIVRA! I just placed order ${orderNum} for LE ${total}. I'll pay via Telda to nivra11.`,
    cod: `Hi NIVRA! I just placed order ${orderNum} for LE ${total}. I selected Cash on Delivery.`
  };

  const waBtn = document.getElementById('whatsapp-btn');
  if (waBtn) {
    const msg = encodeURIComponent(waMessages[paymentMethod] || waMessages.fawry);
    waBtn.href = `https://wa.me/201099938634?text=${msg}`;
  }
}

// ===== ACCOUNT PAGE =====
function initAccount() {
  const saved = JSON.parse(localStorage.getItem('nivra-account') || '{}');
  if (saved.firstName) document.getElementById('acc-first').value = saved.firstName;
  if (saved.lastName) document.getElementById('acc-last').value = saved.lastName;
  if (saved.email) document.getElementById('acc-email').value = saved.email;
  if (saved.phone) document.getElementById('acc-phone').value = saved.phone;

  const nameDisplay = document.getElementById('acc-name-display');
  if (nameDisplay && saved.firstName) nameDisplay.textContent = saved.firstName + ' ' + (saved.lastName || '');

  const statusDisplay = document.getElementById('acc-status');
  if (statusDisplay) statusDisplay.textContent = saved.email ? 'Signed in' : 'Guest User';
}

function saveAccount(e) {
  e.preventDefault();
  const data = {
    firstName: document.getElementById('acc-first').value,
    lastName: document.getElementById('acc-last').value,
    email: document.getElementById('acc-email').value,
    phone: document.getElementById('acc-phone').value,
  };
  localStorage.setItem('nivra-account', JSON.stringify(data));

  const msg = document.getElementById('acc-save-msg');
  if (msg) {
    msg.style.display = 'flex';
    setTimeout(() => msg.style.display = 'none', 2500);
  }

  const nameDisplay = document.getElementById('acc-name-display');
  if (nameDisplay) nameDisplay.textContent = data.firstName + ' ' + data.lastName;

  const statusDisplay = document.getElementById('acc-status');
  if (statusDisplay) statusDisplay.textContent = 'Signed in';
}


// ===== TOAST NOTIFICATION =====
function showToast(msg, duration = 2500) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), duration);
}

// ===== DISCOUNT CODES =====
const DISCOUNT_CODES = {
  'NIVRA10': { type: 'percent', value: 10 },
  'NIVRA20': { type: 'percent', value: 20 },
  'WELCOME': { type: 'fixed', value: 50 },
  'FREESHIP': { type: 'fixed', value: 0 }
};

let appliedDiscount = null;

function applyDiscount() {
  const code = document.getElementById('discount-code')?.value.trim().toUpperCase();
  const successEl = document.getElementById('discount-success');
  const errorEl = document.getElementById('discount-error');

  if (!code) return;
  if (successEl) successEl.style.display = 'none';
  if (errorEl) errorEl.style.display = 'none';

  const discount = DISCOUNT_CODES[code];
  if (!discount) {
    if (errorEl) { errorEl.textContent = 'Invalid discount code.'; errorEl.style.display = 'block'; }
    return;
  }

  appliedDiscount = { code, ...discount };
  const subtotal = getCartTotal();
  const savings = discount.type === 'percent' ? Math.round(subtotal * discount.value / 100) : discount.value;

  if (successEl) { successEl.textContent = `✓ Code applied! You save LE ${savings}`; successEl.style.display = 'block'; }
  updateCheckoutTotal();
}

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname;

  // Inject navbar (checkout/success have their own static nav)
  const skipNavPages = ['checkout.html', 'success.html'];
  const simpleNavPages = ['about.html', 'contact.html', 'account.html'];
  if (!skipNavPages.some(p => path.includes(p))) {
    const isSimple = simpleNavPages.some(p => path.includes(p));
    injectNavbar(isSimple ? 'simple' : 'full');
  }

  updateCartUI();

  // Page-specific init
  if (path.includes('product.html')) loadProductDetail();
  else if (path.includes('shop.html')) initShop();
  else if (path.includes('checkout.html')) loadCheckout();
  else if (path.includes('success.html')) loadSuccess();
  else if (path.includes('account.html')) initAccount();
  else if (path.includes('new-arrivals.html')) {
    const newProducts = products.filter(p => !p.soldOut);
    renderProducts('new-arrivals-products', newProducts);
  } else if (path.includes('index.html') || path === '/' || path.endsWith('/')) {
    const featured = products.filter(p => p.featured);
    renderProducts('featured-products', featured);
  }

  // Close search on outside click
  document.addEventListener('click', (e) => {
    const bar = document.getElementById('search-bar');
    const dropdown = document.getElementById('search-results-dropdown');
    if (bar && !bar.contains(e.target) && !e.target.closest('.nav-btn')) {
      bar.classList.remove('active');
      if (dropdown) dropdown.style.display = 'none';
    }
  });
});
