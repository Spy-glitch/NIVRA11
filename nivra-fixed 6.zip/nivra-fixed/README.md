# NIVRA - Static HTML Website

A premium streetwear e-commerce website built with pure HTML, CSS, and JavaScript.

## 🚀 Quick Start

Simply open `index.html` in your browser!

No build process, no dependencies, no server required.

## 📁 Structure

```
nivra-static/
├── index.html          # Home page
├── shop.html           # Shop page
├── product.html        # Product detail
├── checkout.html       # Checkout
├── success.html        # Order success
├── account.html        # Account page
├── about.html          # About page
├── contact.html        # Contact page
├── new-arrivals.html   # New arrivals
├── css/
│   └── style.css       # All styles
├── js/
│   └── app.js          # All functionality
└── images/             # Image folder
```

## 🛒 Features

- Responsive design (mobile-first)
- Shopping cart with localStorage
- Product filtering and sorting
- Multiple payment methods
- Smooth animations
- SEO optimized

## 💳 Payment Methods

- Fawry
- Vodafone Cash
- Telda
- Cash on Delivery

## 🌐 Deployment

### Netlify (Recommended)
1. Go to [netlify.com](https://netlify.com)
2. Drag & drop this folder
3. Done!

### GitHub Pages
1. Create GitHub repository
2. Upload files
3. Enable GitHub Pages

### Any Web Server
Just upload the files to any hosting provider.

## 📱 Mobile

Works perfectly on iPhone, Android, and all devices.

## 📝 License

MIT License - Free for personal and commercial use.
